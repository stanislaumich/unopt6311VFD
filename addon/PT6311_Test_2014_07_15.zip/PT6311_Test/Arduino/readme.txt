A test for VFD Panel driven by PT6311 controller
================================================

1. Copy the content of Library folder to ARDUINO_INSTALLATION_FOLDER\libraries;
2. Restart Arduino IDE;
3. Open PT6311_Test04_Sketch.ino in Arduino IDE;
4. Redefine VFD_CS_PIN, VFD_CLK_PIN, VFD_DATA_PIN with values in accordance to your wiring 
     between Arduino board and VFD panel;
5. Relace VFD_DISP_MODE_12D16S in PT6311_Test01_Sketch.ino with value which is relevant to 
   your VFD panel;
6. Compile the sketch and test it;